//*****************************************
// creted by    : Jayakumar Budha
// Date         : 29-12-2009  
// Control Name : Dado's Chart User Control 
// Purpose      : To use this Control build the Dado's Chart Reports to use in all udyog Products
//*****************************************

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.Configuration;
using System.IO;
using DevExpress.XtraCharts;
using System.Drawing.Imaging;
using DevExpress.XtraPrintingLinks;
using DevExpress.XtraPrinting;



namespace DadosChartControl
{
    public partial class DadosChartControl : UserControl
    {
        //Contractor of the Control
        #region Constructor
        public DadosChartControl()
        {
            InitializeComponent();

            _ApprenceName = DadosControl.AppearanceName;
            _ChartType = DadosControl.SeriesTemplate.View.ToString();
            _ChartTitle = DadosControl.Titles[0].Text;


            if (DadosControl.Titles[0].Dock == DevExpress.XtraCharts.ChartTitleDockStyle.Bottom)
            {
                _ChartTitleLocation = DevExpress.XtraCharts.ChartTitleDockStyle.Bottom.ToString();
            }
            else if (DadosControl.Titles[0].Dock == DevExpress.XtraCharts.ChartTitleDockStyle.Left)
            {
                _ChartTitleLocation = DevExpress.XtraCharts.ChartTitleDockStyle.Left.ToString();
            }
            else if (DadosControl.Titles[0].Dock == DevExpress.XtraCharts.ChartTitleDockStyle.Right)
            {
                _ChartTitleLocation = DevExpress.XtraCharts.ChartTitleDockStyle.Right.ToString();
            }
            else if (DadosControl.Titles[0].Dock == DevExpress.XtraCharts.ChartTitleDockStyle.Top)
            {
                _ChartTitleLocation = DevExpress.XtraCharts.ChartTitleDockStyle.Top.ToString();
            }

            if (DadosControl.Titles[0].Alignment == System.Drawing.StringAlignment.Center)
            {
                _ChartTitleAlienment = System.Drawing.StringAlignment.Center.ToString();
            }
            else if (DadosControl.Titles[0].Alignment == System.Drawing.StringAlignment.Far)
            {
                _ChartTitleAlienment = System.Drawing.StringAlignment.Far.ToString();
            }
            else if (DadosControl.Titles[0].Alignment == System.Drawing.StringAlignment.Near)
            {
                _ChartTitleAlienment = System.Drawing.StringAlignment.Near.ToString();
            }



            XYDiagram diagram = (XYDiagram)DadosControl.Diagram;
            _ChartAxisXTitle = diagram.AxisX.Title.Text;
            _ChartAxisYTitle = diagram.AxisY.Title.Text;

            _ChartAxisXVisiblity = diagram.AxisX.Visible;
            _ChartAxisYVisiblity = diagram.AxisY.Visible;

            _ChartAxisXThickness = diagram.AxisX.Thickness;
            _ChartAxisYThickness = diagram.AxisY.Thickness;

            _ChartAxisXStaggered = diagram.AxisX.Label.Staggered;
            _ChartAxisYStaggered = diagram.AxisY.Label.Staggered;

            _LegendHAlienment = DadosControl.Legend.AlignmentHorizontal.ToString();
            _LegendVAlienment = DadosControl.Legend.AlignmentVertical.ToString();
            _LegendVisiblity = DadosControl.Legend.Visible;
        }
        #endregion

        // created by Jayakumar Budha on 29-12-2009
        // this veriable are use for total class
        #region Member Veriables

        List<string> NumaricColumns = new List<string>();
        List<string> StringColumns = new List<string>();
        Series[] NumberOfSeries = null;
        ViewType viewType = new ViewType();
        bool isHavingNumaricValue = false;

        #endregion

        // created by Jayakumar Budha on 29-12-2009
        // this properties for control properties(Globle/internall)
        #region Public Properties

        //private int _NumberOfSeries;
        ///// <summary>
        ///// Number Of Series Need To Create
        ///// </summary>
        //[CategoryAttribute("Dados"), DescriptionAttribute("Number Of Series Need To Create")]
        //public int NumberOfSeries
        //{
        //    get { return _NumberOfSeries; }
        //    set { _NumberOfSeries = value; }
        //}

        private DataSet _DataValues;
        /// <summary>
        /// DataSet for Binding The Chart Control
        /// </summary>
        [CategoryAttribute("Dados"), DescriptionAttribute("DataSet For Binding The Chart Control")]
        public DataSet DataValues
        {
            get { return _DataValues; }
            set { _DataValues = value; }
        }

        private string _ApprenceName;//=new DevExpress.XtraCharts.ChartControl().AppearanceName;
        /// <summary>
        /// Set Or Get Chart Apprience Name
        /// </summary>        
        [TypeConverter(typeof(ApprenceNames)),
       CategoryAttribute("Dados"), DescriptionAttribute("Get Or Set Chart Apprience Name")]
        public string AppearenceName
        {
            get { return _ApprenceName; }
            set { _ApprenceName = value; }
        }

        private string _ChartType;// = new DevExpress.XtraCharts.ChartControl().SeriesTemplate.View.ToString();
        /// <summary>
        /// Get Or Set To Display Chart Type
        /// </summary>        
        [TypeConverter(typeof(ChartTypes)),
       CategoryAttribute("Dados"), DescriptionAttribute("Get Or Set To Display Chart Type")]
        public string ChartType
        {
            get { return _ChartType; }
            set { _ChartType = value; }
        }

        private string _ChartTitle;
        /// <summary>
        /// Set Or Get Chart Title
        /// </summary>        
        [CategoryAttribute("Dados"), DescriptionAttribute("Get Or Set Chart Title")]
        public string ChartTitle
        {
            get { return _ChartTitle; }
            set { _ChartTitle = value; }
        }

        private string _ChartAxisXTitle;
        /// <summary>
        /// Get Or Set Chart AxisX Title
        /// </summary>        
        [CategoryAttribute("Dados"), DescriptionAttribute("Get Or Set Chart AxisX Title")]
        public string ChartAxisXTitle
        {
            get { return _ChartAxisXTitle; }
            set { _ChartAxisXTitle = value; }
        }

        private string _ChartAxisYTitle;
        /// <summary>
        /// Get Or Set Chart AxisY Title
        /// </summary>        
        [CategoryAttribute("Dados"), DescriptionAttribute("Get Or Set Chart AxisY Title")]
        public string ChartAxisYTitle
        {
            get { return _ChartAxisYTitle; }
            set { _ChartAxisYTitle = value; }
        }

        private bool _ChartAxisXVisiblity;
        /// <summary>
        /// Get Or Set Chart AxisX Visiblity
        /// </summary>        
        [CategoryAttribute("Dados"), DescriptionAttribute("Get Or Set Chart AxisX Visiblity")]
        public bool ChartAxisXVisiblity
        {
            get { return _ChartAxisXVisiblity; }
            set { _ChartAxisXVisiblity = value; }
        }

        private bool _ChartAxisYVisiblity;
        /// <summary>
        /// Get Or Set Chart AxisY Visiblity
        /// </summary>        
        [CategoryAttribute("Dados"), DescriptionAttribute("Get Or Set Chart AxisY Visiblity")]
        public bool ChartAxisYVisiblity
        {
            get { return _ChartAxisYVisiblity; }
            set { _ChartAxisYVisiblity = value; }
        }

        private bool _ChartAxisXStaggered;
        /// <summary>
        /// Get Or Set a Value Indicating Whether Axis Labels/Axis Custom Labels Are Positioned In The Staggered Order 
        /// </summary>        
        [CategoryAttribute("Dados"), DescriptionAttribute("Get Or Set a Value Indicating Whether Axis Labels/Axis Custom Labels Are Positioned In The Staggered Order ")]
        public bool ChartAxisXStaggered
        {
            get { return _ChartAxisXStaggered; }
            set { _ChartAxisXStaggered = value; }
        }

        private bool _ChartAxisYStaggered;
        /// <summary>
        /// Get Or Set a Value Indicating Whether Axis Labels/Axis Custom Labels Are Positioned In The Staggered Order 
        /// </summary>        
        [CategoryAttribute("Dados"), DescriptionAttribute("Get Or Set a Value Indicating Whether Axis Labels/Axis Custom Labels Are Positioned In The Staggered Order ")]
        public bool ChartAxisYStaggered
        {
            get { return _ChartAxisYStaggered; }
            set { _ChartAxisYStaggered = value; }
        }

        private int _ChartAxisXThickness;
        /// <summary>
        /// Get Or Set Chart AxisX Thickness
        /// </summary>        
        [CategoryAttribute("Dados"), DescriptionAttribute("Get Or Set Chart AxisX Thickness")]
        public int ChartAxisXThickness
        {
            get { return _ChartAxisXThickness; }
            set { _ChartAxisXThickness = value; }
        }

        private int _ChartAxisYThickness;
        /// <summary>
        /// Get Or Set Chart AxisY Thickness
        /// </summary>        
        [CategoryAttribute("Dados"), DescriptionAttribute("Get Or Set Chart AxisY Thickness")]
        public int ChartAxisYThickness
        {
            get { return _ChartAxisYThickness; }
            set { _ChartAxisYThickness = value; }
        }


        private string _LegendHAlienment;// = new DevExpress.XtraCharts.ChartControl().SeriesTemplate.View.ToString();
        /// <summary>
        /// Get Or Set To Display Chart Legend Horizontal Alienment
        /// </summary>        
        [TypeConverter(typeof(LegendHAlienmentNames)),
     CategoryAttribute("Dados"), DescriptionAttribute("Get Or Set To Display Chart Legend Horizontal Alienment")]
        public string LegendHAlienment
        {
            get { return _LegendHAlienment; }
            set { _LegendHAlienment = value; }
        }

        private string _LegendVAlienment;// = new DevExpress.XtraCharts.ChartControl().SeriesTemplate.View.ToString();
        /// <summary>
        /// Get Or Set To Display Chart Legend Vertical Alienment
        /// </summary>        
        [TypeConverter(typeof(LegendVAlienmentNames)),
      CategoryAttribute("Dados"), DescriptionAttribute("Get Or Set To Display Chart Legend Vertical Alienment")]
        public string LegendVAlienment
        {
            get { return _LegendVAlienment; }
            set { _LegendVAlienment = value; }
        }

        private bool _LegendVisiblity;
        /// <summary>
        /// Get Or Set Chart Legent Visiblity
        /// </summary>        
        [CategoryAttribute("Dados"), DescriptionAttribute("Get Or Set Chart Legent Visiblity")]
        public bool LegendVisiblity
        {
            get { return _LegendVisiblity; }
            set { _LegendVisiblity = value; }
        }


        private string _ChartTitleLocation;
        /// <summary>
        /// Get Or Set Location Of The Chart Title
        /// </summary>
        ///
        [TypeConverter(typeof(ChartTitlesLocation)),
     CategoryAttribute("Dados"), DescriptionAttribute("Get Or Set Location Of The Chart Title")]
        public string ChartTitleLocation
        {
            get { return _ChartTitleLocation; }
            set { _ChartTitleLocation = value; }
        }

        private string _ChartTitleAlienment;
        /// <summary>
        /// Get Or Set Location Of The Chart Title
        /// </summary>
        ///
        [TypeConverter(typeof(ChartTitlesAlianment)),
     CategoryAttribute("Dados"), DescriptionAttribute("Get Or Set Location Of The Chart Title")]
        public string ChartTitleAlienment
        {
            get { return _ChartTitleAlienment; }
            set { _ChartTitleAlienment = value; }
        }

        #endregion

        // created by Jayakumar Budha on 29-12-2009
        // this methods can call in out side of this class
        #region Public Functions

        #region Show Chart
        /// <summary>
        /// To Show The Chart
        /// </summary>
        public void showChart()
        {
            try
            {
                #region Assign Legend Values

                Legend _legend = DadosControl.Legend;

                if (LegendHAlienment == LegendAlignmentHorizontal.Center.ToString())
                    _legend.AlignmentHorizontal = LegendAlignmentHorizontal.Center;
                else if (LegendHAlienment == LegendAlignmentHorizontal.Left.ToString())
                    _legend.AlignmentHorizontal = LegendAlignmentHorizontal.Left;
                else if (LegendHAlienment == LegendAlignmentHorizontal.LeftOutside.ToString())
                    _legend.AlignmentHorizontal = LegendAlignmentHorizontal.LeftOutside;
                else if (LegendHAlienment == LegendAlignmentHorizontal.Right.ToString())
                    _legend.AlignmentHorizontal = LegendAlignmentHorizontal.Right;
                else if (LegendHAlienment == LegendAlignmentHorizontal.RightOutside.ToString())
                    _legend.AlignmentHorizontal = LegendAlignmentHorizontal.RightOutside;

                if (LegendVAlienment == LegendAlignmentVertical.Bottom.ToString())
                    _legend.AlignmentVertical = LegendAlignmentVertical.Bottom;
                else if (LegendVAlienment == LegendAlignmentVertical.BottomOutside.ToString())
                    _legend.AlignmentVertical = LegendAlignmentVertical.BottomOutside;
                else if (LegendVAlienment == LegendAlignmentVertical.Center.ToString())
                    _legend.AlignmentVertical = LegendAlignmentVertical.Center;
                else if (LegendVAlienment == LegendAlignmentVertical.Top.ToString())
                    _legend.AlignmentVertical = LegendAlignmentVertical.Top;
                else if (LegendVAlienment == LegendAlignmentVertical.TopOutside.ToString())
                    _legend.AlignmentVertical = LegendAlignmentVertical.TopOutside;

                _legend.Visible = LegendVisiblity;

                #endregion

                #region Assign Diagram Values

                XYDiagram _diagram = (XYDiagram)DadosControl.Diagram;

                _diagram.AxisX.Thickness = ChartAxisXThickness;
                _diagram.AxisY.Thickness = ChartAxisYThickness;

                _diagram.AxisX.Title.Text = ChartAxisXTitle;
                _diagram.AxisY.Title.Text = ChartAxisYTitle;

                _diagram.AxisX.Visible = ChartAxisXVisiblity;
                _diagram.AxisY.Visible = ChartAxisYVisiblity;

                _diagram.AxisX.Label.Staggered = ChartAxisXStaggered;
                _diagram.AxisY.Label.Staggered = ChartAxisYStaggered;

                #endregion

                #region Assign Title of the Chart

                DadosControl.Titles.Clear();
                ChartTitle title = new ChartTitle();
                title.Text = ChartTitle;
                DadosControl.Titles.Add(title);

                #endregion

                #region Assign Apprence of the Chart

                DadosControl.AppearanceName = AppearenceName;

                #endregion

                #region Clearing The Default Series In Chart

                DadosControl.Series.Clear();

                #endregion

                #region Assign Title alienment
                if (_ChartTitleAlienment == System.Drawing.StringAlignment.Center.ToString())
                {
                    DadosControl.Titles[0].Alignment = System.Drawing.StringAlignment.Center;
                }
                else if (_ChartTitleAlienment == System.Drawing.StringAlignment.Far.ToString())
                {
                    DadosControl.Titles[0].Alignment = System.Drawing.StringAlignment.Far;
                }
                else if (_ChartTitleAlienment == System.Drawing.StringAlignment.Near.ToString())
                {
                    DadosControl.Titles[0].Alignment = System.Drawing.StringAlignment.Near;
                }
                #endregion

                #region Assign Title Location
                if (_ChartTitleLocation == DevExpress.XtraCharts.ChartTitleDockStyle.Bottom.ToString())
                {
                    DadosControl.Titles[0].Dock = DevExpress.XtraCharts.ChartTitleDockStyle.Bottom;
                }
                else if (_ChartTitleLocation == DevExpress.XtraCharts.ChartTitleDockStyle.Left.ToString())
                {
                    DadosControl.Titles[0].Dock = DevExpress.XtraCharts.ChartTitleDockStyle.Left;
                }
                else if (_ChartTitleLocation == DevExpress.XtraCharts.ChartTitleDockStyle.Right.ToString())
                {
                    DadosControl.Titles[0].Dock = DevExpress.XtraCharts.ChartTitleDockStyle.Right;
                }
                else if (_ChartTitleLocation == DevExpress.XtraCharts.ChartTitleDockStyle.Top.ToString())
                {
                    DadosControl.Titles[0].Dock = DevExpress.XtraCharts.ChartTitleDockStyle.Top;
                }
                #endregion

                if (DataValues != null)
                {
                    if (DataValues.Tables.Count > 0 && DataValues.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataColumn col in DataValues.Tables[0].Columns)
                        {
                            if (col.DataType.Name == DbType.Decimal.ToString())
                            {
                                isHavingNumaricValue = true;
                                break;
                            }
                        }

                        if (isHavingNumaricValue == false)
                        {
                            MessageBox.Show("Please Provide atlest one numaric Value to show the Chart");
                        }
                        else
                        {
                            foreach (DataColumn col in DataValues.Tables[0].Columns)
                            {
                                if (col.DataType.Name == DbType.Decimal.ToString() || col.DataType.Name == DbType.Double.ToString() || col.DataType.Name == DbType.Int16.ToString() || col.DataType.Name == DbType.Int32.ToString() || col.DataType.Name == DbType.Int64.ToString() || col.DataType.Name == DbType.UInt16.ToString() || col.DataType.Name == DbType.UInt32.ToString() || col.DataType.Name == DbType.UInt64.ToString())
                                {
                                    NumaricColumns.Add(col.ColumnName);
                                }
                                else if (col.DataType.Name == DbType.String.ToString() || col.DataType.Name == DbType.StringFixedLength.ToString() || col.DataType.Name == DbType.VarNumeric.ToString())
                                {
                                    StringColumns.Add(col.ColumnName);
                                }
                            }

                            if (NumaricColumns.Count > 0 && StringColumns.Count > 0)
                            {
                                NumberOfSeries = new Series[NumaricColumns.Count];
                            }

                            for (int i = 0; i < NumberOfSeries.Length; i++)
                            {
                                NumberOfSeries[i] = new Series();

                                foreach (DataRow row in DataValues.Tables[0].Rows)
                                {

                                    NumberOfSeries[i].Name = NumaricColumns[i];
                                    NumberOfSeries[i].Points.Add(new DevExpress.XtraCharts.SeriesPoint(row[StringColumns[0]].ToString(), new double[] { Convert.ToDouble(row[NumaricColumns[i]]) }));
                                }

                                switch (ChartType)
                                {
                                    case "Area":
                                        viewType = ViewType.Area;
                                        break;
                                    case "Bar":
                                        viewType = ViewType.Bar;
                                        break;
                                    case "CandleStick":
                                        viewType = ViewType.CandleStick;
                                        break;
                                    case "FullStackedArea":
                                        viewType = ViewType.FullStackedArea;
                                        break;
                                    case "FullStackedBar":
                                        viewType = ViewType.FullStackedBar;
                                        break;
                                    case "Gantt":
                                        viewType = ViewType.Gantt;
                                        break;
                                    case "Line":
                                        viewType = ViewType.Line;
                                        break;
                                    case "ManhattanBar":
                                        viewType = ViewType.ManhattanBar;
                                        break;
                                    case "Pie":
                                        if (NumberOfSeries.Length > 0)
                                        {
                                            for (int Length = 0; Length < NumberOfSeries.Length; Length++)
                                            {
                                                if (NumberOfSeries[Length].Name.ToLower() == "qty".ToLower())
                                                {
                                                    break;
                                                }
                                            }
                                        }
                                        viewType = ViewType.Pie;
                                        break;
                                    case "Pie3D":
                                        viewType = ViewType.Pie3D;
                                        break;
                                    case "Point":
                                        viewType = ViewType.Point;
                                        break;
                                    case "RangeBar":
                                        viewType = ViewType.RangeBar;
                                        break;
                                    case "SideBySideGantt":
                                        viewType = ViewType.SideBySideGantt;
                                        break;
                                    case "SideBySideRangeBar":
                                        viewType = ViewType.SideBySideRangeBar;
                                        break;
                                    case "StackedArea":
                                        viewType = ViewType.StackedArea;
                                        break;
                                    case "StackedBar":
                                        viewType = ViewType.StackedBar;
                                        break;
                                    case "StepLine":
                                        viewType = ViewType.StepLine;
                                        break;
                                    case "Stock":
                                        viewType = ViewType.Stock;
                                        break;
                                    default:
                                        break;
                                }
                                NumberOfSeries[i].ChangeView(viewType);
                                DadosControl.Series.Add(NumberOfSeries[i]);
                            }

                        }


                    }
                }
                else
                {
                    MessageBox.Show("Please Add the Data Values", Application.ProductName + "- Information", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Application.ProductName + "- Error", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
            }
        }

        #endregion
        /// <summary>
        /// To Export Chart As A HTML
        /// </summary>
        public void ExportToHtml()
        {
            ExportTo("HTML Document", "HTML Documents (*.htm; *.html)|*.htm; *.html", "HTML");
        }
        /// <summary>
        /// To Export Chart As A MHTML 
        /// </summary>
        public void ExportToMht()
        {
            ExportTo("MHT Document", "MHT Documents (*.mht)|*.mht", "MHT");
        }
        /// <summary>
        /// To Export Chart As A PDF 
        /// </summary>
        public void ExportToPdf()
        {
            ExportTo("PDF Document", "PDF Documents (*.pdf)|*.pdf", "PDF");
        }
        /// <summary>
        /// To Export Chart As A Excel 
        /// </summary>
        public void ExportToXls()
        {
            ExportTo("XLS Document", "XLS Documents (*.xls)|*.xls", "XLS");
        }
        /// <summary>
        /// To Export Chart As A Image 
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="format"></param>
        public void ExportToImage(string format)
        {
            ImageFormat imageFormat = null;
            ImageCodecInfo imageCodecInfo = null;
            format = format.ToLower();
            switch (format)
            {
                case ("bmp"):
                    imageFormat = ImageFormat.Bmp;
                    imageCodecInfo = FindImageCodec(ImageFormat.Bmp);
                    break;
                case ("emf"):
                    imageFormat = ImageFormat.Emf;
                    imageCodecInfo = FindImageCodec(ImageFormat.Emf);
                    break;
                case ("exif"):
                    imageFormat = ImageFormat.Exif;
                    imageCodecInfo = FindImageCodec(ImageFormat.Exif);
                    break;
                case ("gif"):
                    imageFormat = ImageFormat.Gif;
                    imageCodecInfo = FindImageCodec(ImageFormat.Gif);
                    break;
                case ("icon"):
                    imageFormat = ImageFormat.Icon;
                    imageCodecInfo = FindImageCodec(ImageFormat.Icon);
                    break;
                case ("jpeg"):
                    imageFormat = ImageFormat.Jpeg;
                    imageCodecInfo = FindImageCodec(ImageFormat.Jpeg);
                    break;
                case ("memorybmp"):
                    imageFormat = ImageFormat.MemoryBmp;
                    imageCodecInfo = FindImageCodec(ImageFormat.MemoryBmp);
                    break;
                case ("png"):
                    imageFormat = ImageFormat.Png;
                    imageCodecInfo = FindImageCodec(ImageFormat.Png);
                    break;
                case ("tiff"):
                    imageFormat = ImageFormat.Tiff;
                    imageCodecInfo = FindImageCodec(ImageFormat.Tiff);
                    break;
                case ("wmf"):
                    imageFormat = ImageFormat.Wmf;
                    imageCodecInfo = FindImageCodec(ImageFormat.Wmf);
                    break;
                default:
                    break;
            }
            string formatTitle = String.Format("{0} image", imageCodecInfo.FormatDescription);
            string fileMask = imageCodecInfo.FilenameExtension;
            ExportTo(formatTitle, String.Format("{0} ({1})|{1}", formatTitle, fileMask), "IMAGE", imageFormat, false);
        }
        /// <summary>
        /// To Print Chart
        /// </summary>
        public void Print()
        {
            if (DadosControl != null)
                DadosControl.Print(DevExpress.XtraCharts.Printing.PrintSizeMode.Zoom);
        }
        /// <summary>
        /// To See Print Priview For Chart
        /// </summary>
        public void PrintPreview()
        {
            if (DadosControl != null)
                DadosControl.ShowPrintPreview(DevExpress.XtraCharts.Printing.PrintSizeMode.Zoom);
        }
        /// <summary>
        /// A Static Method for Save File Dialog
        /// </summary>
        /// <param name="title"></param>
        /// <param name="filter"></param>
        /// <returns></returns>
        static string ShowSaveFileDialog(string title, string filter)
        {
            SaveFileDialog dlg = new SaveFileDialog();
            string name = Application.ProductName;
            int n = name.LastIndexOf(".") + 1;
            if (n > 0) name = name.Substring(n, name.Length - n);
            dlg.Title = "Export To " + title;
            dlg.FileName = name;
            dlg.Filter = filter;
            if (dlg.ShowDialog() == DialogResult.OK) return dlg.FileName;
            return "";
        }
        /// <summary>
        /// A Static Method for open File Dialog
        /// </summary>
        /// <param name="fileName"></param>
        static void OpenFile(string fileName)
        {
            if (MessageBox.Show("Do you want to open this file?", "Export To...", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    System.Diagnostics.Process process = new System.Diagnostics.Process();
                    process.StartInfo.FileName = fileName;
                    process.StartInfo.Verb = "Open";
                    process.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Normal;
                    process.Start();
                }
                catch
                {
                    MessageBox.Show("Cannot find an application on your system suitable for openning the file with exported data.", Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        /// <summary>
        /// To Show Or Hide The Legend Of the Chart Control
        /// </summary>
        public void ShowHideLegend()
        {
            if (DadosControl.Legend.Visible == true)
            {
                DadosControl.Legend.Visible = false;
                DadosControl.Refresh();
            }
            else
            {
                DadosControl.Legend.Visible = true;
                DadosControl.Refresh();
            }
        }

        /// <summary>
        /// Returns An Array Of Strings That Represent The Names Of All The Appearances In The Chart.
        /// </summary>
        /// <returns>string[]</returns>
        public string[] GetAppearanceNames()
        {
            DevExpress.XtraCharts.ChartControl chart = new ChartControl();
            string[] AppearanceNames = chart.GetAppearanceNames();
            return AppearanceNames;
        }
        /// <summary>
        /// Seting the Apperence Name To Chart.
        /// </summary>
        public void SetAppreanceNameToChart(string AppName)
        {
            this.AppearenceName = AppName;
            DadosControl.AppearanceName = this.AppearenceName;
            DadosControl.Update();
            DadosControl.Refresh();
        }

        public CompositeLink PrintOrPrintPreviewChart()
        {
            PrintingSystem ps = new PrintingSystem();
            DevExpress.XtraPrintingLinks.CompositeLink compositeLink = new DevExpress.XtraPrintingLinks.CompositeLink();
            compositeLink.PrintingSystem = ps;

            PrintableComponentLink link = new PrintableComponentLink();
            link.Component = DadosControl;
            compositeLink.Links.Add(link);

            return compositeLink;
        }
        #endregion

        // created by Jayakumar Budha on 29-12-2009
        // this Methods will call on with in this class
        #region Private Methods
        /// <summary>
        /// To Export Chart In MSEXCEL,HTML,MHTML,IMAGE(BMP(Bitmap Image Format),GIF(Graphics Interchange Format),PNG(Portable Network Graphics),JPEG(Joint PhotoGraphic Experts Group),EMF(Enhanced Windows Metafile Image Format),EXIF(Exchangble Image File),ICON(Windows Icon Image Format),TIFF(Tag Image File Format),WMF(Windows Metafile Image Format)), And PDF
        /// </summary>
        /// <param name="title"></param>
        /// <param name="filter"></param>
        /// <param name="exportFormat"></param>
        private void ExportTo(string title, string filter, string exportFormat)
        {
            ExportTo(title, filter, exportFormat, null, true);
        }
        /// <summary>
        /// To Export Chart In MSEXCEL,HTML,MHTML,IMAGE(BMP(Bitmap Image Format),GIF(Graphics Interchange Format),PNG(Portable Network Graphics),JPEG(Joint PhotoGraphic Experts Group),EMF(Enhanced Windows Metafile Image Format),EXIF(Exchangble Image File),ICON(Windows Icon Image Format),TIFF(Tag Image File Format),WMF(Windows Metafile Image Format)), And PDF
        /// </summary>
        /// <param name="title"></param>
        /// <param name="filter"></param>
        /// <param name="exportFormat"></param>
        /// <param name="format"></param>
        /// <param name="checkPrinterAvailable"></param>
        public void ExportTo(string title, string filter, string exportFormat, ImageFormat format, bool checkPrinterAvailable)
        {
            if (DadosControl == null)
                return;
            string fileName = ShowSaveFileDialog(title, filter);
            if (fileName != "")
            {
                Cursor currentCursor = Cursor.Current;
                Cursor.Current = Cursors.WaitCursor;
                switch (exportFormat)
                {
                    case "HTML":
                        DadosControl.ExportToHtml(fileName);
                        break;
                    case "MHT":
                        DadosControl.ExportToMht(fileName);
                        break;
                    case "PDF":
                        DadosControl.ExportToPdf(fileName);
                        break;
                    case "XLS":
                        DadosControl.ExportToXls(fileName);
                        break;
                    case "IMAGE":
                        DadosControl.ExportToImage(fileName, format);
                        break;
                }
                Cursor.Current = currentCursor;
                OpenFile(fileName);
            }
        }

        public void SavePDF(string filename)
        {
            DadosControl.ExportToPdf(filename);
        }

        public void changeViewType(string type)
        {
            bool isPieType = false;
            Series[] series = DadosControl.Series.ToArray();

            foreach (Series se in series)
            {
                switch (type)
                {
                    case "Area":
                        if (se.Visible == false)
                        {
                            se.Visible = true;
                        }
                        viewType = ViewType.Area;
                        break;
                    case "Bar":
                        if (se.Visible == false)
                        {
                            se.Visible = true;
                        }
                        viewType = ViewType.Bar;
                        break;
                    case "CandleStick":
                        if (se.Visible == false)
                        {
                            se.Visible = true;
                        }
                        viewType = ViewType.CandleStick;
                        break;
                    case "FullStackedArea":
                        if (se.Visible == false)
                        {
                            se.Visible = true;
                        }
                        viewType = ViewType.FullStackedArea;
                        break;
                    case "FullStackedBar":
                        if (se.Visible == false)
                        {
                            se.Visible = true;
                        }
                        viewType = ViewType.FullStackedBar;
                        break;
                    case "Gantt":
                        if (se.Visible == false)
                        {
                            se.Visible = true;
                        }
                        viewType = ViewType.Gantt;
                        break;
                    case "Line":
                        if (se.Visible == false)
                        {
                            se.Visible = true;
                        }
                        viewType = ViewType.Line;
                        break;
                    case "ManhattanBar":
                        if (se.Visible == false)
                        {
                            se.Visible = true;
                        }
                        viewType = ViewType.ManhattanBar;
                        break;
                    case "Pie":
                        if (se.Name.ToLower() == "qty".ToLower())
                        {
                            se.Visible = false;//View.Dispose();
                            isPieType = true;
                            break;
                        }
                        viewType = ViewType.Pie;
                        break;
                    case "Pie3D":
                        if (se.Name.ToLower() == "qty".ToLower())
                        {
                            se.Visible = false;//View.Dispose();
                            isPieType = true;
                            break;
                        }
                        viewType = ViewType.Pie3D;
                        break;
                    case "Point":
                        if (se.Visible == false)
                        {
                            se.Visible = true;
                        }
                        viewType = ViewType.Point;
                        break;
                    case "RangeBar":
                        if (se.Visible == false)
                        {
                            se.Visible = true;
                        }
                        viewType = ViewType.RangeBar;
                        break;
                    case "SideBySideGantt":
                        if (se.Visible == false)
                        {
                            se.Visible = true;
                        }
                        viewType = ViewType.SideBySideGantt;
                        break;
                    case "SideBySideRangeBar":
                        if (se.Visible == false)
                        {
                            se.Visible = true;
                        }
                        viewType = ViewType.SideBySideRangeBar;
                        break;
                    case "StackedArea":
                        if (se.Visible == false)
                        {
                            se.Visible = true;
                        }
                        viewType = ViewType.StackedArea;
                        break;
                    case "StackedBar":
                        if (se.Visible == false)
                        {
                            se.Visible = true;
                        }
                        viewType = ViewType.StackedBar;
                        break;
                    case "StepLine":
                        if (se.Visible == false)
                        {
                            se.Visible = true;
                        }
                        viewType = ViewType.StepLine;
                        break;
                    case "Stock":
                        if (se.Visible == false)
                        {
                            se.Visible = true;
                        }
                        viewType = ViewType.Stock;
                        break;
                    default:
                        break;
                }
                if (isPieType == false && type.ToLower() != "pie".ToLower())
                {
                    se.ChangeView(viewType);
                    se.PointOptions.PointView = PointView.Values;
                    se.PointOptions.ValueNumericOptions.Format = NumericFormat.General;
                    se.PointOptions.ValueNumericOptions.Precision = 0;
                    if (DadosControl.Legend.Visible == false)
                    {
                        DadosControl.Legend.Visible = true;
                    }
                    DadosControl.Update();
                    DadosControl.Refresh();
                }
                else if (isPieType == false && type.ToLower() == "pie".ToLower())
                {
                    se.ChangeView(viewType);
                    se.PointOptions.PointView = PointView.ArgumentAndValues;
                    se.PointOptions.ValueNumericOptions.Format = NumericFormat.Percent;
                    se.PointOptions.ValueNumericOptions.Precision = 0;
                    DadosControl.Legend.Visible = false;
                    DadosControl.Update();
                    DadosControl.Refresh();
                }
                else if (isPieType == false && type.ToLower() == "Pie3D".ToLower())
                {
                    se.ChangeView(viewType);
                    se.PointOptions.PointView = PointView.ArgumentAndValues;
                    se.PointOptions.ValueNumericOptions.Format = NumericFormat.Percent;
                    se.PointOptions.ValueNumericOptions.Precision = 0;
                    DadosControl.Legend.Visible = false;
                    DadosControl.Update();
                    DadosControl.Refresh();
                }

            }

        }


        private ImageCodecInfo FindImageCodec(ImageFormat format)
        {
            ImageCodecInfo[] infos = ImageCodecInfo.GetImageEncoders();
            foreach (ImageCodecInfo item in infos)
            {
                if (item.FormatID.Equals(format.Guid))
                    return item;
            }
            return null;
        }

        public void exportthis()
        {
            //RadarDiagram radarDiagram = DadosControl.Diagram as RadarDiagram;
        }

        public void ChangeChartTitle(Font FontDetails, Color ColorDetails)
        {
            try
            {
                
                DadosControl.Titles[0].Text = ChartTitle;
                DadosControl.Titles[0].Font = FontDetails;
                DadosControl.Titles[0].TextColor = ColorDetails;
                DadosControl.Update();
                DadosControl.Refresh();
            }
            catch (Exception ex)
            {

            }  
        }


        #endregion
    }
}

#region Commented Code

#endregion