using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

namespace DadosChartControl
{
    public class ApprenceNames : StringConverter
    {
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            DevExpress.XtraCharts.ChartControl chart = new DevExpress.XtraCharts.ChartControl();
            return new StandardValuesCollection(chart.GetAppearanceNames());
        }
    }

    public class LegendHAlienmentNames : StringConverter
    {
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            return new StandardValuesCollection(Enum.GetNames(typeof(DevExpress.XtraCharts.LegendAlignmentHorizontal)));
        }
    }

    public class LegendVAlienmentNames : StringConverter
    {
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            return new StandardValuesCollection(Enum.GetNames(typeof(DevExpress.XtraCharts.LegendAlignmentVertical)));
        }
    }

    public class ChartTypes : StringConverter
    {
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            return new StandardValuesCollection(Enum.GetNames(typeof(DevExpress.XtraCharts.ViewType)));
        }
    }

    public class ChartTitlesLocation : StringConverter
    {
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            return new StandardValuesCollection(Enum.GetNames(typeof(DevExpress.XtraCharts.ChartTitleDockStyle)));
        }
    }

    public class ChartTitlesAlianment : StringConverter
    {
        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }
        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            
            return new StandardValuesCollection(Enum.GetNames(typeof(System.Drawing.StringAlignment)));
        }
    }
}
