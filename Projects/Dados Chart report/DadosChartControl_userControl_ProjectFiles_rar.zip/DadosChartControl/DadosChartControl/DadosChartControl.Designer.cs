namespace DadosChartControl
{
    partial class DadosChartControl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DevExpress.XtraCharts.XYDiagram xyDiagram1 = new DevExpress.XtraCharts.XYDiagram();
            DevExpress.XtraCharts.Series series1 = new DevExpress.XtraCharts.Series();
            DevExpress.XtraCharts.Series series2 = new DevExpress.XtraCharts.Series();
            DevExpress.XtraCharts.ChartTitle chartTitle1 = new DevExpress.XtraCharts.ChartTitle();
            this.DadosControl = new DevExpress.XtraCharts.ChartControl();
            ((System.ComponentModel.ISupportInitialize)(this.DadosControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(xyDiagram1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(series1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(series2)).BeginInit();
            this.SuspendLayout();
            // 
            // DadosControl
            // 
            xyDiagram1.AxisX.Label.Staggered = true;
            this.DadosControl.Diagram = xyDiagram1;
            this.DadosControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DadosControl.Location = new System.Drawing.Point(0, 0);
            this.DadosControl.Name = "DadosControl";
            series1.Name = "Series 1";
            series1.PointOptionsTypeName = "PointOptions";
            series2.Name = "Series 2";
            series2.PointOptionsTypeName = "PointOptions";
            this.DadosControl.Series.AddRange(new DevExpress.XtraCharts.Series[] {
            series1,
            series2});
            this.DadosControl.SeriesTemplate.PointOptionsTypeName = "PointOptions";
            this.DadosControl.Size = new System.Drawing.Size(526, 407);
            this.DadosControl.TabIndex = 0;
            this.DadosControl.Titles.AddRange(new DevExpress.XtraCharts.ChartTitle[] {
            chartTitle1});
            // 
            // DadosChartControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.DadosControl);
            this.Name = "DadosChartControl";
            this.Size = new System.Drawing.Size(526, 407);
            ((System.ComponentModel.ISupportInitialize)(xyDiagram1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(series1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(series2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DadosControl)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraCharts.ChartControl DadosControl;
    }
}
