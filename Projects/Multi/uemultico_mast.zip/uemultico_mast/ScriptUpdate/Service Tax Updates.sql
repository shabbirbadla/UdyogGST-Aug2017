Alter Table Co_Mast Add Serapl Bit				--- Service Tax Applicable
Alter Table Co_Mast Add FBCode Varchar(20)		--- Focal Bank Code
Alter Table Co_Mast Add FBName Varchar(60)		--- Focal Bank Name
Alter Table Co_Mast Add FBAdd Varchar(250)		--- Focal Bank Address
Alter Table Co_Mast Add SREgn Varchar(060)		--- Service Reg. No. And Date
Alter Table Co_Mast Add SERadjper Decimal(6,6)	--- Service Tax. Cr. Adj. [%]
Alter Table Co_Mast Add SerCode Varchar(20)		--- Code Of Major Service
Alter Table Co_Mast Add Serty Varchar(60)		--- Major Service
Alter Table Co_Mast Add TypeORG Varchar(150)	--- Type of organization

