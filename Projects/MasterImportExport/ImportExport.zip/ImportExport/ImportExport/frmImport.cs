using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Configuration;
using System.Reflection;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
namespace ImportExport
{
    public partial class frmImport : Form
    {
        string connStr, iden_flds, unique_flds;
        string fileName;
        SqlDataAdapter da;
        DataSet ds;
        SqlConnection cn;

        /// <summary>
        /// / Variable required for Log Maintenance.
        /// </summary>
        string logTime=string.Empty;
        int logUpdatedRec=0, logInsertRec=0, logUnImportedRec=0, logTotalRec;

        public frmImport(string cnStr)
        {
            InitializeComponent();
            //connStr = "Data Source=Udyog3;Initial Catalog=Master;Uid=sa;Pwd=sa@1985";
            connStr = cnStr;
            cn = new SqlConnection(connStr);
        }

        /// <summary>
        //// This method is useful for getting the database name in company master
        /// </summary>
        public void GetDatabases()
        {
            OpenConnection();
            da = new SqlDataAdapter("Select dbname=rtrim(dbname),Co_name=rtrim(Co_name) From Vudyog..Co_Mast Order by Co_Name", cn);
            ds = new DataSet();
            da.Fill(ds, "Database_vw");
            cboDatabase.DataSource = ds;
            cboDatabase.DisplayMember = "Database_vw.co_name";
            cboDatabase.ValueMember = "Database_vw.dbname";
            //GetTables();
        }

        ///// <summary>
        ///// This method is useful for getting the master table 
        ///// </summary>
        public void GetTables()
        {
            if (cboDatabase.Text != "")
            {
                try
                {
                    OpenConnection();
                    if (ds.Tables["Table_vw"] != null)
                    {
                        ds.Tables["Table_vw"].Clear();
                    }
                    da = new SqlDataAdapter("Select FileName,code=[Name],iden_fldS,unique_flds From " + cboDatabase.SelectedValue.ToString() + "..Mastcode Where Code Not In ('PM','TM','BM') Order by [Name]", cn);
                    da.Fill(ds, "Table_vw");
                    cboTable.DataSource = ds;
                    cboTable.DisplayMember = "Table_vw.code";
                    cboTable.ValueMember = "Table_vw.Filename";
                }
                catch (Exception e)
                {
                    MessageBox.Show("Error in Table getting Method:" + e.Message, "Import-Export Master");
                }
            }
        }

        ///// <summary>
        ///// This method is useful for opening the Connection
        ///// </summary>
        public SqlConnection OpenConnection()
        {
            if (cn == null)
            {
                try
                {
                    cn.Open();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while opening connection :" + ex.Message, "Import-Export Master");
                }
            }
            else
            {
                if (cn.State == ConnectionState.Closed)
                {
                    try
                    {
                        cn.Open();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error while opening connection :" + ex.Message, "Import-Export Master");
                    }
                }
            }
            return cn;
        }

        ///// <summary>
        ///// This method is Importing the data to Dataset from Excel Sheet
        ///// </summary>
        public void ImporttoDataset()
        {
            try
            {
                string oleconnStr = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + fileName + ";Extended Properties=\"Excel 8.0;IMEX=1;HDR:NO;\"";
                OleDbConnection oleconn = new OleDbConnection(oleconnStr);
                oleconn.Open();
                System.Data.DataTable dtTables = oleconn.GetOleDbSchemaTable(System.Data.OleDb.OleDbSchemaGuid.Tables, null);
                string strTablename = dtTables.Rows[0]["TABLE_NAME"].ToString();
                string strSQL = "SELECT * FROM [" + strTablename + "]";

                OleDbCommand cmd = new OleDbCommand(strSQL, oleconn);
                DataSet oleds = new DataSet();
                OleDbDataAdapter oldda = new OleDbDataAdapter(cmd);
                oldda.Fill(oleds, cboTable.SelectedValue.ToString());
                GetActualData();
                if (DatasetValidity(ds.Tables["Data_vw"], oleds.Tables[0])==true)
                {
                    CompareDataset(ds, oleds);    
                }
                oleconn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error in Import to Sql Method: " + ex.Message, "Import-Export Master");
            }

        }
        ///// <summary>
        ///// This method is used for Comparing the Dataset i.e. for missed match excel sheet and selected table.
        ///// </summary>
        public bool DatasetValidity(DataTable Dt, DataTable xDt)
        {
            bool exists=false;
            for (int j = 0; j < xDt.Columns.Count; j++)
            {
                exists = false;
                for (int i = 0; i < Dt.Columns.Count; i++)
                {
                    if (xDt.Columns[j].ColumnName==Dt.Columns[i].ColumnName)
                    {
                        exists = true;
                        break;
                    }
                }
                if (exists==false)
                {
                    break;
                }

            }
            if (exists==false)
            {
                MessageBox.Show("Please check the file of Import or selected Master. Both are not matching Or structure of the file and data are not matching.", "ImportExport Master", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }
        ///// <summary>
        ///// This method is used for Comparing the Dataset, 1 from Actual Table & 2nd from Excel Sheet
        ///// </summary>
        public void CompareDataset(DataSet Ds, DataSet xDs)
        {
            string[] args;
            string cond = "";
            bool exists;
            args = unique_flds.Split(',');
            string strLogText = string.Empty;
            if (Ds.Tables["Data_vw"].Rows.Count > 0 || xDs.Tables[0].Rows.Count > 0)
            {
                logTotalRec = xDs.Tables[0].Rows.Count - 1;
                for (int j = 1; j < xDs.Tables[0].Rows.Count; j++)      // for ignoring the description row of the sheet.
//                    for (int j = 0; j < xDs.Tables[0].Rows.Count; j++)
                {
                    toolStripProgressBar1.Maximum = xDs.Tables[0].Rows.Count;
                    exists = false;
                    if (args.Length == 1)
                    {
                        for (int i = 0; i < Ds.Tables["Data_vw"].Rows.Count; i++)
                        {
                            if (xDs.Tables[0].Rows[j][args[0]].ToString().Trim() == Ds.Tables["Data_vw"].Rows[i][args[0]].ToString().Trim())
                            {
                                exists = true;
                                cond = " Where " + args[0].ToString() + " = '" + xDs.Tables[0].Rows[j][args[0]].ToString() + "' ";
                                break;
                            }
                        }
                        if (exists == true)
                        {
                            bool catchException=false;
                            string exMessage = string.Empty;
                            try
                            {
                                OpenConnection();
                                SqlCommand cmd = new SqlCommand((UpdateString(Ds.Tables["Data_vw"], xDs.Tables[0], xDs.Tables[0].Rows[j])).ToString() + cond, cn);
                                cmd.ExecuteNonQuery();
                                //strLogText = strLogText + args[0].ToString() + " = " + xDs.Tables[0].Rows[j][args[0]].ToString().Trim() + " updated Successfully." + "|";
                                strLogText = j.ToString() + "\t\t\t\t " + "Record Updated Successfully for column " +xDs.Tables[0].Rows[0][args[0].ToString()].ToString() + " = " + xDs.Tables[0].Rows[j][args[0]].ToString().Trim();
                                logUpdatedRec = logUpdatedRec + 1;
                            }
                            catch (Exception ex)
                            {
                                //strLogText = strLogText + "Error in Comparing Dataset method while updating in the row for " + args[0].ToString() + " = " + xDs.Tables[0].Rows[j][args[0]].ToString().Trim() + " Err.: " + ex.Message + "|";
                                strLogText = j.ToString() + "\t\t U001 \t\t " + "Record Not Updated for column " + xDs.Tables[0].Rows[0][args[0].ToString()].ToString() + " = " + xDs.Tables[0].Rows[j][args[0]].ToString().Trim();
                                logUnImportedRec = logUnImportedRec + 1;
                                catchException=true;
                                exMessage = ex.Message;
                            }
                            finally
                            {
                                WriteLogFile(strLogText);
                                if (catchException==true)
                                {
                                    WriteLogFile("\t\t\t\t" + exMessage );
                                }
                            }
                        }
                        else
                        {
                            bool catchException = false;
                            string exMessage = string.Empty;
                            try
                            {
                                if (xDs.Tables[0].Rows[j][args[0]].ToString() != "")
                                {
                                    OpenConnection();
                                    SqlCommand cmd = new SqlCommand(InsertString(Ds.Tables["Data_vw"], xDs.Tables[0], xDs.Tables[0].Rows[j]), cn);
                                    cmd.ExecuteNonQuery();
                                    //strLogText = strLogText + args[0].ToString() + " = " + xDs.Tables[0].Rows[j][args[0]].ToString().Trim() + " inserted Successfully." + "|";
                                    strLogText = j.ToString() + "\t\t\t\t " + "Record Insert Successfully for column " + xDs.Tables[0].Rows[0][args[0].ToString()].ToString() + " = " + xDs.Tables[0].Rows[j][args[0]].ToString().Trim();
                                    logInsertRec = logInsertRec + 1;
                                }
                            }
                            catch (Exception ex)
                            {
                                //strLogText = strLogText + "Error in Comparing Dataset method while inserting in the row for " + args[0].ToString() + " = " + xDs.Tables[0].Rows[j][args[0]].ToString().Trim() + " Err.: " + ex.Message + "|";
                                strLogText = j.ToString() + "\t\t I001 \t\t " + "Record Not Inserted for column " + xDs.Tables[0].Rows[0][args[0].ToString()].ToString() + " = " + xDs.Tables[0].Rows[j][args[0]].ToString().Trim();
                                catchException = true;
                                logUnImportedRec = logUnImportedRec + 1;
                                exMessage = ex.Message;
                                //MessageBox.Show("Error in Comparing Dataset method while inserting in the row : " + xDs.Tables[0].Rows[j][args[0]].ToString() + ". "  + ex.Message);
                            }
                            finally
                            {
                                WriteLogFile(strLogText);
                                if (catchException == true)
                                {
                                    WriteLogFile("\t\t\t\t" + exMessage);
                                }
                            }
                        }
                        toolStripProgressBar1.Value = j + 1;
                    }
                }
                //WriteLogFile(strLogText);
                toolStripProgressBar1.Value = 0;
                MessageBox.Show("Data Imported Successfully... \n Please check the log file : "+Application.StartupPath+"\\Log.txt", "Import-Export Master");
                cn.Close();
                //this.Close();
            }
        }

        ///// <summary>
        ///// This method is used for Writing Log file to txt File
        ///// </summary>
        private void WriteLogFile(string stringLog)
        {
                try
                {
                    if (!string.IsNullOrEmpty(stringLog))
                    {
                        using (FileStream file = new FileStream(System.Windows.Forms.Application.StartupPath + "\\" + logTime+".txt", FileMode.Append, FileAccess.Write))
                        {
                            StreamWriter streamWriter = new StreamWriter(file);
                            streamWriter.WriteLine(stringLog);
                            //streamWriter.Write(streamWriter.NewLine);
                            streamWriter.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
        }

        ///// <summary>
        ///// This method is getting actual data from table
        ///// </summary>
        public void GetActualData()
        {
            OpenConnection();
            if (ds.Tables["Data_vw"]!=null)
            {
                ds.Tables.Remove(ds.Tables["Data_vw"]);
            }
            da = new SqlDataAdapter("Select * From " + cboDatabase.SelectedValue.ToString() + ".." + cboTable.SelectedValue.ToString(), cn);
            da.Fill(ds, "Data_vw");
        }
        ///// <summary>
        ///// This method is used for generating Insert String for SQL
        ///// </summary>
        public string InsertString(System.Data.DataTable srcTable, System.Data.DataTable dat, DataRow row)
        {
            string insStr;
            insStr = "Insert Into " + cboDatabase.SelectedValue.ToString() + ".." + cboTable.SelectedValue.ToString() + " (";
            for (int i = 0; i < dat.Columns.Count; i++)
            {
                if (dat.Columns[i].ColumnName.ToString().ToUpper() != iden_flds.ToUpper())
                {
                    insStr = insStr + " [" + dat.Columns[i].ColumnName.ToString() + "],";
                }
            }
            insStr = insStr.Substring(0, insStr.Length - 1) + " ) values (";
            for (int i = 0; i < row.ItemArray.Length; i++)
            {
                if (srcTable.Columns[dat.Columns[i].ColumnName.ToString()].ColumnName == dat.Columns[i].ColumnName.ToString())
                {
                    switch (srcTable.Columns[dat.Columns[i].ColumnName.ToString()].DataType.ToString())
                    {
                        case "System.Int16":
                            insStr = insStr + Convert.ToInt16(row[i].ToString() == "" ? 0 : row[i]).ToString().Trim() + ",";
                            break;
                        case "System.Int32":
                            insStr = insStr + Convert.ToInt32(row[i].ToString() == "" ? 0 : row[i]).ToString().Trim() + ",";
                            break;
                        case "System.Int64":
                            insStr = insStr + Convert.ToInt64(row[i].ToString() == "" ? 0 : row[i]).ToString().Trim() + ",";
                            break;
                        case "System.Double":
                            insStr = insStr + Convert.ToDouble(row[i].ToString() == "" ? 0 : row[i]).ToString().Trim() + ",";
                            break;
                        case "System.Decimal":
                            insStr = insStr + Convert.ToDecimal(row[i].ToString() == "" ? 0 : row[i]).ToString().Trim() + ",";
                            break;
                        case "System.String":
                        case "System.DBNull":
                            insStr = insStr + "'" + row[i].ToString().Trim() + "',";
                            break;
                        case "System.DateTime":
                            insStr = insStr + "'" + Convert.ToDateTime(row[i].ToString() == "" ? "01/01/1900" : row[i]).ToString().Trim() + "',";
                            break;
                        case "System.Boolean":
                            insStr = insStr + (row[i].ToString().Trim().ToUpper() == "TRUE" ? 1 : 0) + ",";
                            break;
                        default:
                            insStr = insStr + "'" + row[i].ToString().Trim() + "',";
                            break;
                    }
                }
            }
            insStr = insStr.Substring(0, insStr.Length - 1) + ")";
            return insStr;
        }

        ///// <summary>
        ///// This method is used for generating Update String for SQL
        ///// </summary>
        public string UpdateString(System.Data.DataTable srcTable, System.Data.DataTable dat, DataRow row)
        {
            string updStr;
            string[] args;
            args = unique_flds.Split(',');
            updStr = "Update " + cboDatabase.SelectedValue.ToString() + ".." + cboTable.SelectedValue.ToString() + " Set ";
            for (int i = 0; i < dat.Columns.Count; i++)
            {
                if (dat.Columns[i].ColumnName.ToString().ToUpper() != args[0].ToUpper())
                {
                    updStr = updStr + " [" + dat.Columns[i].ColumnName.ToString() + "]=";
                    if (srcTable.Columns[dat.Columns[i].ColumnName.ToString()].ColumnName == dat.Columns[i].ColumnName.ToString())
                    {
                        switch (srcTable.Columns[dat.Columns[i].ColumnName.ToString()].DataType.ToString())
                        {
                            case "System.Int16":
                                updStr = updStr + Convert.ToInt16(row[i].ToString() == "" ? 0 : row[i]).ToString().Trim() + ",";
                                break;
                            case "System.Int32":
                                updStr = updStr + Convert.ToInt32(row[i].ToString() == "" ? 0 : row[i]).ToString().Trim() + ",";
                                break;
                            case "System.Int64":
                                updStr = updStr + Convert.ToInt64(row[i].ToString() == "" ? 0 : row[i]).ToString().Trim() + ",";
                                break;
                            case "System.Double":
                                updStr = updStr + Convert.ToDouble(row[i].ToString() == "" ? 0 : row[i]).ToString().Trim() + ",";
                                break;
                            case "System.Decimal":
                                updStr = updStr + Convert.ToDecimal(row[i].ToString() == "" ? 0 : row[i]).ToString().Trim() + ",";
                                break;
                            case "System.String":
                            case "System.DBNull":
                                updStr = updStr + "'" + (row[i].GetType().ToString() == "System.DateTime" ? Convert.ToDateTime(row[i]).ToString("dd/MM/yyyy HH:mm:ss") : row[i].ToString()) + "',";
                                break;
                            case "System.DateTime":
                                updStr = updStr + "'" + Convert.ToDateTime(row[i].ToString() == "" ? "01/01/1900" : row[i]).ToString().Trim() + "',";
                                break;
                            case "System.Boolean":
                                updStr = updStr + (row[i].ToString().Trim().ToUpper() == "TRUE" ? 1 : 0) + ",";
                                break;
                            default:
                                updStr = updStr + "'" + row[i].ToString().Trim() + "',";
                                break;
                        }
                    }
                }
            }
            updStr = updStr.Substring(0, updStr.Length - 1);
            return updStr;
        }

        ///// <summary>
        ///// This method is validation
        ///// </summary>
        public bool CheckValidation()
        {
            if (txtPath.Text == "")
            {
                MessageBox.Show("Select the file to import.", "Import-Export Master",MessageBoxButtons.OK,MessageBoxIcon.Question);
                txtPath.Focus();
                return false;
            }
            if (cboTable.Text == "")
            {
                MessageBox.Show("Select the master which should be imported.", "Import-Export Master", MessageBoxButtons.OK, MessageBoxIcon.Question);
                cboTable.Focus();
                return false;
            }
            if (cboDatabase.Text == "")
            {
                MessageBox.Show("Select the Company in which data should be imported.","Import-Export Master", MessageBoxButtons.OK, MessageBoxIcon.Question);
                cboDatabase.Focus();
                return false;
            }
            return true;
        }


        private void btnClose_Click(object sender, EventArgs e)
        {
            cn.Close();
            this.Close();
        }

        private void btnImport_Click(object sender, EventArgs e)
        {
            if (CheckValidation() == true)
            {
                if (cboTable.SelectedValue.ToString() != "")
                {
                    DataRow[] dtrow;
                    string y;
                    y = "FileName='" + cboTable.SelectedValue.ToString() + "'";
                    dtrow = ds.Tables["Table_vw"].Select(y);
                    iden_flds = dtrow[0]["iden_flds"].ToString();
                    unique_flds = dtrow[0]["unique_flds"].ToString();

                    logTime = "Import_Status_" + DateTime.Now.ToString("ddMMyyyy hh:mm:ss").Replace(':', '_');
                    WriteLogFile("\t\t\t\t\t\t" + cboDatabase.Text.Trim());
                    WriteLogFile("\t\t\t\t\tImport Status as on " + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss"));
                    WriteLogFile(Convert.ToString('*').PadRight(125, '*'));
                    WriteLogFile("");
                    WriteLogFile("Import Status for "+cboTable.Text.Trim());
                    WriteLogFile(Convert.ToString('~').PadRight(125, '~'));
                    WriteLogFile("Record No. \t"+"Error No.\t"+"Message");
                    WriteLogFile(Convert.ToString('~').PadRight(125, '~'));
                    ImporttoDataset();
                    WriteLogFile(Convert.ToString('~').PadRight(125, '~'));
                    WriteLogFile("Total No. of Records :"+logTotalRec.ToString());
                    WriteLogFile("No. of Records Inserted :"+logInsertRec.ToString());
                    WriteLogFile("No. of Records Updated :"+logUpdatedRec.ToString());
                    WriteLogFile("No. of Records Not Imported :"+logUnImportedRec.ToString());
                    WriteLogFile(Convert.ToString('~').PadRight(125, '~'));
                }
            }
        }


        private void frmImport_Load(object sender, EventArgs e)
        {
            GetDatabases();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Excel Workbooks (*.xls)|*.xls|All files (*.*)|*.*";
            dialog.InitialDirectory = Environment.SpecialFolder.MyComputer.ToString();
            dialog.Title = "Select Excel File";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                fileName = dialog.FileName.ToString();
                txtPath.Text = fileName;
            }
        }

        private void cboTable_Click(object sender, EventArgs e)
        {
            GetTables();
        }

        private void cboDatabase_SelectedIndexChanged(object sender, EventArgs e)
        {
            //GetTables();
        }

        private void cboDatabase_SelectedValueChanged(object sender, EventArgs e)
        {
            //GetTables();
        }

        private void cboDatabase_Leave(object sender, EventArgs e)
        {
            GetTables();
        }

             


        
    }
}
