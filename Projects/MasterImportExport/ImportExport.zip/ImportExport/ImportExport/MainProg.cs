using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ImportExport
{
    public partial class MainProg : Form
    {
        //private int childFormNumber = 0;

        public MainProg()
        {
            InitializeComponent();
        }



        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        

        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private string _connStr;
        public string ConnStr
        {
            get { return _connStr; }
            set { _connStr = value; }
        }

        private void exportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExport f = new frmExport(ConnStr);
            f.MdiParent = this;
            f.Show();
        }

        private void importToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmImport g = new frmImport(ConnStr);
            g.MdiParent = this;
            g.Show();
        }

        private void MainProg_Load(object sender, EventArgs e)
        {
            GetInfo.iniFile ini = new GetInfo.iniFile(Application.StartupPath + "\\" + "Visudyog.ini");
            GetInfo.EncDec x = new GetInfo.EncDec();
            string Server = ini.IniReadValue("DataServer", "Name");
            string user = ini.IniReadValue("DataServer", x.OnEncrypt("myName", x.Enc("myName", "User")));
            string pass = ini.IniReadValue("DataServer", x.OnEncrypt("myName", x.Enc("myName", "Pass")));
            ConnStr = "Data Source=" + Server + ";Initial Catalog=Master;Uid=" + x.Dec("myName", x.OnDecrypt("myName", user)) + ";Pwd=" + x.Dec("myName", x.OnDecrypt("myName", pass));

        }
    }
}
