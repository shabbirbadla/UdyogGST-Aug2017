using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Reflection;
using Excel=Microsoft.Office.Interop.Excel;
using System.Windows.Forms;

namespace ImportExport
{
    public partial class frmExport : Form
    {
        string connStr, iden_flds, Maxcoldesc;
        SqlDataAdapter da;
        DataSet ds;
        SqlConnection cn;
        Excel.Application app;
        Excel.Workbook workbook;
        public frmExport(string cnStr)
        {
            InitializeComponent();
            //connStr = "Data Source=Udyog3;Initial Catalog=Master;Uid=sa;Pwd=sa@1985";            
            connStr = cnStr;
            cn = new SqlConnection(connStr);
        }


        private void frmExport_Load(object sender, EventArgs e)
        {
            GetDatabases();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            cn.Close();
            this.Close();
        }
        ///// <summary>
        ///// This method is useful for getting the database name in company master
        ///// </summary>
        public void GetDatabases()
        {
            OpenConnection();
            da = new SqlDataAdapter("Select dbname=rtrim(dbname),Co_name=rtrim(Co_name) From Vudyog..Co_Mast Order by Co_Name", cn);
            ds = new DataSet();
            da.Fill(ds, "Database_vw");
            cboDatabase.DataSource = ds;
            cboDatabase.DisplayMember = "Database_vw.co_name";
            cboDatabase.ValueMember = "Database_vw.dbname";
            //GetTables();
        }

        ///// <summary>
        ///// This method is useful for getting the master table 
        ///// </summary>
        public void GetTables()
        {

            if (cboDatabase.Text != "")
            {
                OpenConnection();
                if (ds.Tables["Table_vw"] != null)
                {
                    ds.Tables["Table_vw"].Clear();
                }
                da = new SqlDataAdapter("Select FileName,code=[Name],iden_flds From " + cboDatabase.SelectedValue.ToString() + "..Mastcode Where Code Not In ('PM','TM','BM') Order by [Name]", cn);
                da.Fill(ds, "Table_vw");
                cboTable.DataSource = ds;
                cboTable.DisplayMember = "Table_vw.code";
                cboTable.ValueMember = "Table_vw.Filename";
            }
        }
        ///// <summary>
        ///// This method is useful for opening the Connection
        ///// </summary>
        public SqlConnection OpenConnection()
        {
            if (cn == null)
            {
                try
                {
                    cn.Open();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error while opening connection :" + ex.Message,"Import-Export Master");
                }
            }
            else
            {
                if (cn.State == ConnectionState.Closed)
                {
                    try
                    {
                        cn.Open();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error while opening connection :" + ex.Message, "Import-Export Master");
                    }
                }
            }
            return cn;
        }

        private void cboDatabase_Leave(object sender, EventArgs e)
        {
            GetTables();
        }

        private void cboTable_Click(object sender, EventArgs e)
        {
            GetTables();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.RootFolder = Environment.SpecialFolder.MyComputer;
            folderBrowserDialog1.Description = "Select Path to Save Exported File ";
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                txtPath.Text = folderBrowserDialog1.SelectedPath.ToString();
            }
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            CreateWorkbook();
            if (cboTable.SelectedValue.ToString() != "")
            {
                DataRow[] dtrow;
                string y;
                y = "FileName='" + cboTable.SelectedValue.ToString() + "'";
                dtrow = ds.Tables["Table_vw"].Select(y);
                iden_flds = dtrow[0]["iden_flds"].ToString();
            }

            ExportTable("SELECT * FROM " + cboDatabase.SelectedValue.ToString() + ".." + cboTable.SelectedValue.ToString(), cboTable.SelectedValue.ToString());
            SaveWorkbook();
            //CloseWorkBook();
        }
        ///// <summary>
        ///// This method is useful for Creating New Work Book
        ///// </summary>
        private void CreateWorkbook()
        {
            try
            {
                app = new Excel.ApplicationClass();
                //app = new Microsoft.Office.Interop.Excel.Application();
                app.Visible = false;

                workbook = app.Workbooks.Add(1);
            }
            catch (Exception e)
            {
                Console.Write("Error in CreateWorkbook Method: " + e.ToString());
            }
        }

        ///// <summary>
        ///// This method is useful for Closing Excel Application
        ///// </summary>
        public void CloseExcelApplication()
        {
            if (workbook != null)
            {
                workbook.Close(false, null, null);
                System.Runtime.InteropServices.Marshal.ReleaseComObject(workbook);
                //Console.WriteLine("Workbook Closed.");
            }
            if (app != null)
            {
                app.Workbooks.Close();
                app.Quit();
                System.Runtime.InteropServices.Marshal.ReleaseComObject(app);
                //Console.WriteLine("Excel Quit");
            }
            app = null;
            GC.Collect();
        }

        ///// <summary>
        ///// This method is Exporting the data to Excel Sheet
        ///// </summary>
        public void ExportTable(string query, string sheetName)
        {
            SqlDataAdapter rowsDa;
            DataSet rowsDs = new DataSet();
            try
            {
                Excel.Worksheet worksheet = (Excel.Worksheet)workbook.Sheets.get_Item(1);
                worksheet.Name = sheetName;
                OpenConnection();
                rowsDa = new SqlDataAdapter(query, cn);
                rowsDa.Fill(rowsDs, "rDataset");

                rowsDa = new SqlDataAdapter("use " + cboDatabase.SelectedValue.ToString() + " Select ObjName,Value as [Desc] From ::fn_listextendedproperty (NULL, 'user', 'dbo', 'table', '" + cboTable.SelectedValue.ToString() + "','column', default)", cn);
                rowsDa.Fill(rowsDs, "rowDesc");

                if (iden_flds != "")
                {
                    rowsDs.Tables["rDataset"].Columns.Remove(iden_flds);
                }

                for (int n = 0; n < rowsDs.Tables["rDataset"].Columns.Count; n++)
                {
                    createHeaders(worksheet, 1, n + 1, rowsDs.Tables["rDataset"].Columns[n].ColumnName);
                    createDescription(worksheet, 2, n + 1, rowsDs.Tables["rDataset"].Columns[n].ColumnName);
                    for (int p = 0; p < rowsDs.Tables["rowDesc"].Rows.Count; p++)
                    {
                        if (rowsDs.Tables["rDataset"].Columns[n].ColumnName == rowsDs.Tables["rowDesc"].Rows[p][0].ToString())
                        {
                            createDescription(worksheet, 2, n + 1, rowsDs.Tables["rowDesc"].Rows[p][1].ToString());
                            break;
                        }

                    }
                }
                Maxcoldesc = GetMaxColumnofExcel(rowsDs.Tables["rDataset"].Columns.Count);
                int rowCounter = 3;
                toolStripProgressBar1.Maximum = rowsDs.Tables["rDataset"].Rows.Count;
                for (int i = 0; i < rowsDs.Tables["rDataset"].Rows.Count; i++)
                {
                    for (int n = 0; n < rowsDs.Tables["rDataset"].Columns.Count; n++)
                    {
                        addData(worksheet, rowCounter, n + 1, rowsDs.Tables["rDataset"].Rows[i][n].ToString().Trim());
                    }
                    toolStripProgressBar1.Value = i;
                    rowCounter++;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("Error in Export table method.: " + e.ToString(), "Import-Export Master");
            }

        }
        ///// <summary>
        ///// This method is Creating the Headers in the Excel Sheet
        ///// </summary>
        public void createHeaders(Excel.Worksheet worksheet, int row, int col, string htext)
        {
            worksheet.Cells[row, col] = htext;
        }

        ///// <summary>
        ///// This method is Creating the Column Description in the Excel Sheet
        ///// </summary>
        public void createDescription(Excel.Worksheet worksheet, int row, int col, string htext)
        {
            worksheet.Cells[row, col] = htext;
        }

        ///// <summary>
        ///// This method is Adding the Data in Excel Sheet
        ///// </summary>
        public void addData(Excel.Worksheet worksheet, int row, int col, string data)
        {
            worksheet.Cells[row, col] = data;
        }

        ///// <summary>
        ///// This method is Saving the Work Book and protecting the worksheet
        ///// </summary>
        public void SaveWorkbook()
        {
            string strPath;
            strPath = (txtPath.Text == "" ? System.Windows.Forms.Application.StartupPath.ToString()+"\\ExportedData" : txtPath.Text);
            String folderPath = @strPath;

            if (!System.IO.Directory.Exists(folderPath))
            {
                System.IO.Directory.CreateDirectory(folderPath);
            }
            string fileNameBase = cboTable.Text + DateTime.Now.ToString("ddMMyyyy hh:mm:ss").Replace(':', ' ');
            String fileName = fileNameBase;
            string ext = ".xls";
            int counter = 1;
            while (System.IO.File.Exists(folderPath + (txtPath.Text.EndsWith("\\") ? "" : "\\") + fileName + ext))
            {
                fileName = fileNameBase + counter; counter++;
            }
            fileName = fileName + ext;
            string filePath = folderPath + (txtPath.Text.EndsWith("\\") ? "" : "\\") + fileName;
            try
            {
                Excel.Worksheet worksheet = (Excel.Worksheet)workbook.Sheets.get_Item(1);
                worksheet.get_Range("A1", Maxcoldesc+"2").Font.Bold = true;
                Excel.AllowEditRanges allowEdits = worksheet.Protection.AllowEditRanges;
                allowEdits.Add("Editable Cell", worksheet.get_Range("A3", Maxcoldesc+ "16348"), Missing.Value);
                worksheet.Protect(null, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value);
                workbook.SaveAs(filePath, Excel.XlFileFormat.xlWorkbookNormal, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Excel.XlSaveAsAccessMode.xlNoChange, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value);
                toolStripProgressBar1.Value = 0;
                MessageBox.Show("Data Exported Successfully to the file " + filePath, "Import-Export Master", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //Excel.XlFileFormat.xlWorkbookDefault
            }
            catch (Exception e)
            {
                MessageBox.Show("Error in Saving the work book.: " + e.ToString(), "Import-Export Master");
            }
            finally
            {
                CloseExcelApplication();
            }
        }
        ///// <summary>
        ///// This method is calculating the maximum column name of Excel Sheet
        ///// </summary>
        public string GetMaxColumnofExcel(int colCount)
        {
            string b = "A", c = "", retstr = "";
            int j = 0, ctr = 0;
            for (int i = 1; i <= colCount; i++)
            {
                if (j == 26)
                {
                    c = Convert.ToChar((Convert.ToInt16(Convert.ToChar(b)) + ctr)).ToString();
                    j = 0;
                    ctr = ctr + 1;
                }
                retstr = c + Convert.ToChar((Convert.ToInt16(Convert.ToChar(b)) + j)).ToString() ;
                j = j + 1;
            }
            return retstr;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            cn.Close();
            this.Close();

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }


    }

}
