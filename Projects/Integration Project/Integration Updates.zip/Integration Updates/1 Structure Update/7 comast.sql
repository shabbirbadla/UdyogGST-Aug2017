use vudyog
alter table co_mast add cocsvid varchar(10)